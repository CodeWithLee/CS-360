package com.example.greetingcard

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.greetingcard.ui.theme.GreetingCardTheme

@Composable
fun LoginScreen() {
    var username by remember { mutableStateOf("") } // User input for username
    var password by remember { mutableStateOf("") } // User input for password
    val context = LocalContext.current

    Box(modifier = Modifier.fillMaxSize()) {

        // Background image shown only during runtime
        Image(
            painter = painterResource(id = R.drawable.fitness),
            contentDescription = "Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Semi-transparent overlay for form readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x40000000))
        )

        // Main login form layout
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center
        ) {
            // App tagline
            Text(
                text = "How Will You Revolv?",
                fontSize = 28.sp,
                color = Color.Green,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Username input field
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )

            // Password input field with visual transformation
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            )

            // Login button
            Button(
                onClick = {
                    if (username.isNotBlank() && password.isNotBlank()) {
                        // Show login success message
                        Toast.makeText(context, "Logged in as $username", Toast.LENGTH_SHORT).show()
                        username = ""
                        password = ""
                    } else {
                        // Show error for missing fields
                        Toast.makeText(context, "Please enter username and password", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Login")
            }

            // Create account button
            OutlinedButton(
                onClick = {
                    Toast.makeText(context, "Redirecting to Create Account screen...", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                Text("Create Account")
            }
        }
    }
}

// Preview for design
@Preview(showBackground = true, showSystemUi = true)
@Composable
fun LoginScreenPreview() {
    GreetingCardTheme {
        LoginScreen()
    }
}
