package com.example.greetingcard

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.greetingcard.ui.theme.GreetingCardTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Data class to represent a weight entry
data class WeightEntry(val date: String, var weight: String)

@Composable
fun WeightTrackerData(
    entries: List<WeightEntry> = emptyList(),
    addEntry: ((String) -> Unit)? = null,
    deleteEntry: ((Int) -> Unit)? = null,
    updateEntry: ((Int, String) -> Unit)? = null,
    isInPreview: Boolean = false
) {
    var weightInput by remember { mutableStateOf("") }
    var editingIndex by remember { mutableStateOf(-1) }
    var editingWeight by remember { mutableStateOf("") }

    val previewEntries = remember { mutableStateListOf<WeightEntry>() }
    val displayedEntries = if (isInPreview) previewEntries else entries

    Box(modifier = Modifier.fillMaxSize()) {
        // Background image fills the entire screen
        Image(
            painter = painterResource(id = R.drawable.scale),
            contentDescription = "Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            alpha = 0.8f
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Weight Entry", fontSize = 24.sp, modifier = Modifier.padding(bottom = 16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = weightInput,
                    onValueChange = { weightInput = it },
                    label = { Text("Weight (lbs)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(onClick = {
                    if (weightInput.isNotBlank()) {
                        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
                        if (isInPreview) {
                            previewEntries.add(WeightEntry(currentDate, weightInput))
                        } else {
                            addEntry?.invoke(weightInput)
                        }
                        weightInput = ""
                    }
                }) {
                    Text("Add")
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("Weight History", fontSize = 20.sp, modifier = Modifier.padding(bottom = 8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Date", fontSize = 16.sp)
                Text("Weight", fontSize = 16.sp)
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxHeight(),
                contentPadding = PaddingValues(4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(displayedEntries) { index, entry ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F7FA))
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxSize(),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (editingIndex == index) {
                                OutlinedTextField(
                                    value = editingWeight,
                                    onValueChange = { editingWeight = it },
                                    label = { Text("Edit Weight") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Button(
                                    onClick = {
                                        if (isInPreview) {
                                            previewEntries[index].weight = editingWeight
                                        } else {
                                            updateEntry?.invoke(index, editingWeight)
                                        }
                                        editingIndex = -1
                                        editingWeight = ""
                                    },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text("Save")
                                }
                            } else {
                                Text("Date: ${entry.date}", fontSize = 14.sp)
                                Text("Weight: ${entry.weight} lbs", fontSize = 16.sp)
                                Row(modifier = Modifier.align(Alignment.End)) {
                                    IconButton(onClick = {
                                        editingIndex = index
                                        editingWeight = entry.weight
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit")
                                    }
                                    IconButton(onClick = {
                                        if (isInPreview) {
                                            previewEntries.removeAt(index)
                                        } else {
                                            deleteEntry?.invoke(index)
                                        }
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HorizontalDivider(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(3.dp)
            .background(Color.Black)
    )
}

@Preview(showSystemUi = true, showBackground = true)
@Composable
fun WeightTrackerDataPreview() {
    GreetingCardTheme {
        WeightTrackerData(isInPreview = true)
    }
}